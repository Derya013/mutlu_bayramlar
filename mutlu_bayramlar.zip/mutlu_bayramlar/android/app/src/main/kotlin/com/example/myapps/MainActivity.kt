package com.example.myapps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
